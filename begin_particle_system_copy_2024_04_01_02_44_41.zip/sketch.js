let myCars = [];

function setup() {
  createCanvas(400, 400);

  // Spawn one object
  // myCars = new Car();
}

function draw() {
  background(255, 125, 0);

  if (frameCount % 3 == 0) {
    myCars.push(new Car(255, 0, 255));
  } else if (frameCount % 3 == 1) {
    myCars.push(new Car(0, 255, 0));
  } else if (frameCount % 3 == 2) {
    myCars.push(new Car(0, 0, 255));
  }

  for (let i = 0; i < myCars.length; i++) {
    myCars[i].display();
    myCars[i].move();
    if (myCars[i].o < 0) {
      myCars.splice(i, 1);
    }
  }

  print(myCars.length);
}

class Car {
  // constructor
  constructor(r, g, b) {
    this.x = mouseX;
    this.y = mouseY; // initialize your attributes here
    this.r = r;
    this.g = g;
    this.b = b;
    this.o = 255;
  }

  // methods

  display() {
    fill(this.r, this.g, this.b, this.o);
    rect(this.x, this.y, 30, 20);
    this.o = this.o - 5;
    
    //this.o = this.o + 2;
  }

  move() {
    this.x = this.x + random(+ -6, 2);
    this.y = this.y - random(- 0, 20);
  }
}
