let timer = 0;
let state = 0;
let img1, img2, img3;

function setup() {
  createCanvas(400, 400);
  imageMode(CENTER);
  img1 = loadImage("assets/breakfast1.jpg");
  img2 = loadImage("assets/breakfast2.jpg");
  img3 = loadImage("assets/breakfast3.jpg");
}

function draw() {
  timerTick();
  switch (state) {
    case 0:
      background(0, 0, 250);
      image(img1, 200, 200, 400, 400);
      break;
    case 1:
      background(0, 200, 0);
      image(img2, 200, 200, 400, 400);
      break;
    case 2:
      background(250, 0, 0);
      image(img3, 200, 200, 400, 400);
      break;
  }
}

function timerTick() {
  timer++;
  if (timer > 3 * 60) {
    state++;
    if (state > 2) {
      state = 0;
    }
    timer = 0;
  }
}
